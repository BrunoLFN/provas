num = int(input("digite um numero entre 1 e 10: "))

if num > 0 and num <11:
    i=1
    result=0
    for i in range(1,10):
       result= num*i
       print(f"{num}x{i}={result}")
       i+=1
else:
    print("não é um numero entre 1 e 10")