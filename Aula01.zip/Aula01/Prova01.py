var1 = "tipo string" #tipo string
var2 = 0 #tipo int
var3 = 0.3 #tipo float
var4 = True #tipo bool

print(type(var1))
print(type(var2))
print(type(var3))
print(type(var4))