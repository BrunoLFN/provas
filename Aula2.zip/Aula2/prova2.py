velo = int(input("digite a velocidade do carro: "))

if velo > 80:
    multa=(velo-80)*20
    print(f"Você foi multado, o valor da sua multa é R${multa},00 ")
else:
    print("velocidade dentro do limite das via")